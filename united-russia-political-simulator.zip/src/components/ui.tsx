"use client";
import type { ReactNode } from "react";
import type { Eff } from "@/game/types";
import { ALL_SYS, FACTIONS, IDEOLOGIES } from "@/game/data/core";
import { MEMBERS } from "@/game/data/people";
import { ORGS, RIVALS } from "@/game/data/parties";

const LABEL: Record<string, string> = {
  ap: "Рейтинг", pc: "Политкапитал", fd: "Касса", un: "Единство", stb: "Стабильность", ec: "Экономика", lv: "Уровень жизни",
  ml: "Армия", pr: "Престиж", fr: "Свободы", co: "Коррупция", seat: "Места в парламенте",
};

export function effLabel(k: string): string | null {
  if (LABEL[k]) return LABEL[k];
  const [p, id] = [k.slice(0, 2), k.slice(2)];
  if (p === "f.") return `Влияние: ${FACTIONS.find((f) => f.id === id)?.name ?? id}`;
  if (p === "l.") return `Лояльность: ${FACTIONS.find((f) => f.id === id)?.name ?? id}`;
  if (p === "m.") return `Лояльность: ${MEMBERS.find((m) => m.id === id)?.name ?? id}`;
  if (p === "r.") return `Рейтинг: ${RIVALS.find((r) => r.id === id)?.name ?? id}`;
  if (p === "o.") return `Орг.: ${ORGS.find((o) => o.id === id)?.name ?? id}`;
  if (p === "i.") return `Идеология: ${IDEOLOGIES.find((i) => i.id === id)?.name ?? id}`;
  return null;
}

export function EffChips({ e, hide }: { e: Eff; hide?: boolean }) {
  if (hide) return null;
  const chips: ReactNode[] = [];
  for (const [k, v] of Object.entries(e)) {
    if (typeof v === "string") {
      if (ALL_SYS[v]) chips.push(<span key={k} className="rounded bg-violet-900/60 px-1.5 py-0.5 text-[11px] text-violet-200">⇒ {ALL_SYS[v].name}</span>);
      continue;
    }
    if (k.startsWith("flag.") || k.startsWith("unflag.") || k.startsWith("kill.")) continue;
    const lab = effLabel(k);
    if (!lab) continue;
    const good = k === "co" ? v < 0 : v > 0;
    chips.push(
      <span key={k} className={`rounded px-1.5 py-0.5 text-[11px] ${good ? "bg-emerald-900/60 text-emerald-200" : "bg-rose-900/60 text-rose-200"}`}>
        {v > 0 ? "+" : ""}{v} {lab}
      </span>,
    );
  }
  return <div className="mt-1 flex flex-wrap gap-1">{chips}</div>;
}

export function Bar({ v, max = 100, color = "#38bdf8", inv }: { v: number; max?: number; color?: string; inv?: boolean }) {
  const pct = Math.max(0, Math.min(100, (v / max) * 100));
  const c = inv ? (pct > 66 ? "#f43f5e" : pct > 40 ? "#f59e0b" : "#22c55e") : color;
  return (
    <div className="h-1.5 w-full overflow-hidden rounded bg-slate-700">
      <div className="h-full rounded" style={{ width: `${pct}%`, background: c }} />
    </div>
  );
}

export function Panel({ title, children, right }: { title?: string; children: ReactNode; right?: ReactNode }) {
  return (
    <section className="rounded-xl border border-slate-700/70 bg-slate-800/70 p-4 shadow">
      {(title || right) && (
        <div className="mb-3 flex items-center justify-between gap-2">
          {title && <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-300">{title}</h3>}
          {right}
        </div>
      )}
      {children}
    </section>
  );
}

export function Btn({ children, onClick, disabled, kind = "primary", className = "" }: { children: ReactNode; onClick?: () => void; disabled?: boolean; kind?: "primary" | "ghost" | "danger" | "good"; className?: string }) {
  const k = {
    primary: "bg-sky-600 hover:bg-sky-500 text-white",
    ghost: "bg-slate-700 hover:bg-slate-600 text-slate-100",
    danger: "bg-rose-700 hover:bg-rose-600 text-white",
    good: "bg-emerald-700 hover:bg-emerald-600 text-white",
  }[kind];
  return (
    <button onClick={onClick} disabled={disabled} className={`rounded-lg px-3 py-1.5 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-40 ${k} ${className}`}>
      {children}
    </button>
  );
}
