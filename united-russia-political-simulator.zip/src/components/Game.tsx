"use client";
import { useEffect, useState } from "react";
import type { DiffId, GameState } from "@/game/types";
import { DIFFS } from "@/game/data/core";
import { ALL_EVENTS, SAVE_KEY, dateStr, newGame, nextMonth, finalScore } from "@/game/engine";
import type { ElectionReport } from "@/game/engine";
import { FOCUS } from "@/game/data/focus";
import { MEMBERS } from "@/game/data/people";
import { ORGS, RIVALS } from "@/game/data/parties";
import { Factions, FocusTrees, Government, Ideology, LogPanel, Members, Opponents, Overview, Systems } from "./Panels";
import { CongressModal, ElectionModal, EventModal, Notice } from "./Modals";
import { Btn } from "./ui";

const TABS = [
  ["ov", "📊 Обзор"], ["mem", "🧑‍💼 Партийцы"], ["fac", "⚔️ Фракции"], ["ide", "🎯 Идеология"], ["foc", "🌳 Решения"],
  ["gov", "🏛️ Правительство"], ["sys", "⚙️ Системы"], ["opp", "🎭 Оппоненты"], ["log", "📜 Журнал"],
] as const;
type Tab = (typeof TABS)[number][0];

export default function Game() {
  const [s, setS] = useState<GameState | null>(null);
  const [ready, setReady] = useState(false);
  const [hasSave, setHasSave] = useState(false);
  const [tab, setTab] = useState<Tab>("ov");
  const [report, setReport] = useState<ElectionReport | null>(null);
  const [notice, setNotice] = useState<{ title: string; lines: string[] } | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) setHasSave(true);
    } catch { /* ignore */ }
    setReady(true);
  }, []);

  useEffect(() => {
    if (s && !s.over) {
      try { localStorage.setItem(SAVE_KEY, JSON.stringify(s)); } catch { /* ignore */ }
    }
  }, [s]);

  const load = () => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) setS(JSON.parse(raw) as GameState);
    } catch { /* ignore */ }
  };
  const start = (d: DiffId) => { setS(newGame(d)); setTab("ov"); };
  const set = (n: GameState) => setS(n);

  if (!ready) return <div className="p-10 text-slate-400">Загрузка…</div>;

  if (!s) {
    return (
      <main className="mx-auto max-w-5xl p-6">
        <header className="mb-6 text-center">
          <div className="text-sm uppercase tracking-widest text-sky-400">Политический симулятор · 2003–2026</div>
          <h1 className="mt-1 text-4xl font-extrabold text-white md:text-5xl">«Единая Россия»: путь партии власти</h1>
          <p className="mx-auto mt-3 max-w-3xl text-slate-300">
            Вы руководите аппаратом партии. Каждый месяц — новые события, решения партийцев и фракций, деревья решений в экономике, политике, армии и дипломатии,
            съезды, выборы и борьба с оппонентами. Можно повторить историю — или создать собственную альтернативную.
          </p>
          <div className="mt-3 flex flex-wrap justify-center gap-2 text-xs text-slate-400">
            <span className="rounded bg-slate-800 px-2 py-1">{ALL_EVENTS.length} событий</span>
            <span className="rounded bg-slate-800 px-2 py-1">{FOCUS.length} решений в 4 деревьях</span>
            <span className="rounded bg-slate-800 px-2 py-1">{MEMBERS.length} партийцев</span>
            <span className="rounded bg-slate-800 px-2 py-1">9 идеологий / 69 субидеологий</span>
            <span className="rounded bg-slate-800 px-2 py-1">{RIVALS.length} партий + {ORGS.length} организаций</span>
            <span className="rounded bg-slate-800 px-2 py-1">10 экономик · 15 госустройств · 9 парламентов</span>
          </div>
        </header>
        {hasSave && <div className="mb-4 text-center"><Btn kind="good" onClick={load}>▶ Продолжить сохранённую игру</Btn></div>}
        <h2 className="mb-2 text-center text-sm font-semibold uppercase text-slate-300">Выберите сложность</h2>
        <div className="grid gap-3 md:grid-cols-5">
          {DIFFS.map((d) => (
            <button key={d.id} onClick={() => start(d.id)} className="rounded-xl border border-slate-700 bg-slate-800/70 p-3 text-left transition hover:border-sky-500 hover:bg-slate-700">
              <div className="text-lg font-bold text-white">{d.name}</div>
              <div className="mt-1 text-xs text-slate-300">{d.desc}</div>
            </button>
          ))}
        </div>
        <p className="mt-6 text-center text-xs text-slate-500">Прогресс сохраняется автоматически в браузере. Все персонажи используются в игровом и сатирическом контексте.</p>
      </main>
    );
  }

  const hasEvents = s.queue.length > 0;
  const pending = !hasEvents && !s.over ? s.pending : null;
  const can = !hasEvents && !pending && !s.over && !report && !notice;

  return (
    <div className="min-h-screen pb-24">
      <header className="sticky top-0 z-30 border-b border-slate-700 bg-slate-900/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-5 gap-y-1 px-4 py-2 text-sm">
          <div className="text-lg font-bold capitalize text-white">📅 {dateStr(s)}</div>
          <div title="Рейтинг">📊 {Math.round(s.st.ap)}%</div>
          <div title="Политкапитал">🪙 {Math.round(s.st.pc)} ПК</div>
          <div title="Касса">💰 {Math.round(s.st.fd)} млн</div>
          <div title="Единство">🤝 {Math.round(s.st.un)}</div>
          <div title="Стабильность">🏛️ {Math.round(s.st.stb)}</div>
          <div title="Экономика">🏭 {Math.round(s.st.ec)}</div>
          <div title="Свободы">🕊️ {Math.round(s.st.fr)}</div>
          <div title="Мандаты">🗳️ {Math.round(s.seats)}%</div>
          <div className="ml-auto flex gap-2">
            <Btn kind="ghost" onClick={() => { if (confirm("Начать новую игру? Текущий прогресс будет потерян.")) { setS(null); } }}>Меню</Btn>
          </div>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-3 pb-2">
          {TABS.map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)} className={`whitespace-nowrap rounded-md px-3 py-1.5 text-sm ${tab === id ? "bg-sky-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}>{label}</button>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-7xl p-4">
        {tab === "ov" && <Overview s={s} />}
        {tab === "mem" && <Members s={s} set={set} />}
        {tab === "fac" && <Factions s={s} set={set} />}
        {tab === "ide" && <Ideology s={s} set={set} />}
        {tab === "foc" && <FocusTrees s={s} set={set} />}
        {tab === "gov" && <Government s={s} set={set} />}
        {tab === "sys" && <Systems s={s} />}
        {tab === "opp" && <Opponents s={s} set={set} />}
        {tab === "log" && <LogPanel s={s} />}
      </main>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-slate-700 bg-slate-900/95 p-3 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3">
          <div className="text-xs text-slate-400">
            {hasEvents ? `Нужно решить события: ${s.queue.length}` : pending ? "Ожидает решения: " + (pending.type === "election" ? "выборы" : "съезд партии") : s.over ? "Игра окончена" : "Все дела месяца сделаны — можно идти дальше."}
          </div>
          <Btn disabled={!can} onClick={() => set(nextMonth(s))} className="px-6 py-2 text-base">Следующий месяц ▶</Btn>
        </div>
      </div>

      {hasEvents && !report && !notice && <EventModal s={s} set={set} />}
      {pending?.type === "election" && !notice && <ElectionModal s={s} set={set} report={report} setReport={setReport} />}
      {pending?.type === "congress" && !notice && <CongressModal s={s} set={set} notify={(title, lines) => setNotice({ title, lines })} />}
      {!pending && report && <ElectionModal s={s} set={set} report={report} setReport={setReport} />}
      {notice && <Notice title={notice.title} lines={notice.lines} onClose={() => setNotice(null)} />}

      {s.over && !report && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="max-w-xl rounded-2xl border border-slate-600 bg-slate-800 p-6 text-center shadow-2xl">
            <div className="text-5xl">{s.over.win ? "🏆" : "💥"}</div>
            <h2 className="mt-2 text-2xl font-extrabold">{s.over.title}</h2>
            <p className="mt-2 text-slate-300">{s.over.text}</p>
            <p className="mt-2 text-sm text-slate-400">Счёт: {finalScore(s)} • Решено событий: {s.resolved}</p>
            <div className="mt-4 flex justify-center gap-2">
              <Btn onClick={() => { try { localStorage.removeItem(SAVE_KEY); } catch { /* ignore */ } setHasSave(false); setS(null); }}>В главное меню</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
