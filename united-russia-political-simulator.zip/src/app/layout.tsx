import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Единая Россия: путь партии власти (2003–2026)",
  description: "Интерактивная политическая текстовая игра-симулятор: события, фракции, идеологии, деревья решений, выборы и съезды.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="min-h-screen bg-slate-900 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
